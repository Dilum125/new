## MARS-11_Bot

<a href="https://t.me/Mars11Lkbot"><img src="https://graph.org/file/59276d20ae3f97897d285.jpg"></a>

## ☘️ Deploy Locally ❤️‍🔥

```bash
git clone https://github.com/DilumBBandara/MARS-11_Bot
cd MARS-11_Bot
nano Bot/config.py
pip3 install -r requirements.txt
bash start
```
