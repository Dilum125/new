import os

bot_username = 'Mars11Lkbot'
CHANNEL = 'Team_Mars_11'
Discussion = 'TeamMars_11'
C_CHANNEL = 'CGSUPDATES'
SUPPORT = 'CGSsupport'

start_sticker_id = 'CAACAgIAAxkBAAIBP2NK3cJnHKz9Tz0N1XY7XnQfnP6iAAJlCwACUas4S_UAAVke-cEmqioE'

TG_API_HASH = '9d2c6cdf712fc6cd9e667567111a1cb8'
TG_API_ID = '9247680'
TG_BOT_TOKEN = '5677621036:AAGx5MalG9-DYun-KCQoj9EB795tr2_utz0'

OWNER = int(5262156299) #oyage id danna
CO_OWNER = int(1746346543)

DATABASE = "mongodb+srv://Dilumb:dilumb12@cluster0.x2zfbab.mongodb.net/?retryWrites=true&w=majority" #Mongo url
